
const STREAMER_HASHKEY = "39fa62e81c7d74d9d18610fa6e3d5bdb";

// 방송 상태 확인 함수
async function fetchStreamerInfo(hashkey) {
  try {
    const response = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${hashkey}`);
    if (!response.ok) return null;
    const data = await response.json();
    if (!data.content || !data.content.channelName || data.content.channelId == null) return null;
    return {
      name: data.content.channelName,
      isLive: data.content.openLive
    };
  } catch (e) {
    console.error("지각 방지: 방송 상태 확인 중 오류 발생", e);
    return null;
  }
}

// 스트리머 상태 체크 및 자동 입장
async function checkStreamers() {
  chrome.storage.local.get(["isLive"], async (res) => {
    const prevIsLive = res.isLive || false;
    const info = await fetchStreamerInfo(STREAMER_HASHKEY);
    if (!info) return;

    const isLive = info.isLive;

    if (isLive && !prevIsLive) {
      chrome.tabs.query({ url: `https://chzzk.naver.com/live/${STREAMER_HASHKEY}` }, (tabs) => {
        if (tabs.length === 0) {
          chrome.tabs.create({ url: `https://chzzk.naver.com/live/${STREAMER_HASHKEY}` });
        }
      });
    }

    chrome.storage.local.set({ isLive });

    setTimeout(checkStreamers, 1000);
  });
}

// 브라우저 시작 또는 확장 설치 시 체크 시작
chrome.runtime.onStartup.addListener(() => {
  checkStreamers();
});
chrome.runtime.onInstalled.addListener(() => {
  checkStreamers();
});

// Service Worker 유지용 알람
chrome.alarms.create("keepAlive", { periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive") {
    console.log("지각 방지: Service Worker 활성 유지 중...");
  }
});
