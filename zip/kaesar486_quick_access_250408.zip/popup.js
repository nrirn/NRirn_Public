const listContainer = document.getElementById("menu-list");
let draggedItem = null;

function renderMenu(menuItems) {
  listContainer.innerHTML = "";

  menuItems.forEach((item, index) => {
    const div = document.createElement("div");
    div.className = "menu-item";
    div.draggable = true;

    if (item.type === "toggle") {
      div.innerHTML = `
        <img src="${item.icon}" alt="${item.name}">
        <span>${item.name}</span>
        <label class="switch">
          <input type="checkbox" class="forceAttendToggle" />
          <span class="slider round"></span>
        </label>
      `;

      setTimeout(() => {
        const toggle = div.querySelector(".forceAttendToggle");
        chrome.storage.local.get("autoAttend", (data) => {
          toggle.checked = data.autoAttend || false;

          toggle.addEventListener("change", (event) => {
            event.stopPropagation();
            chrome.storage.local.set({ autoAttend: toggle.checked });
          });

          toggle.addEventListener("click", (event) => {
            event.stopPropagation();
          });
        });
      }, 0);

    } else {
      div.innerHTML = `
        <img src="${item.icon}" alt="${item.name}">
        <span>${item.name}</span>
      `;
      if (item.link) {
        div.addEventListener("click", () => {
          chrome.tabs.create({ url: item.link });
        });
      }
    }

    div.addEventListener("dragstart", () => {
      draggedItem = index;
      div.classList.add("dragging");
    });

    div.addEventListener("dragend", () => {
      div.classList.remove("dragging");
    });

    div.addEventListener("dragover", (e) => {
      e.preventDefault();
      const draggingOverIndex = index;
      if (draggedItem !== null && draggedItem !== draggingOverIndex) {
        const temp = menuItems[draggedItem];
        menuItems[draggedItem] = menuItems[draggingOverIndex];
        menuItems[draggingOverIndex] = temp;
        draggedItem = draggingOverIndex;
        renderMenu(menuItems);
        chrome.storage.local.set({ menuItems });
      }
    });

    listContainer.appendChild(div);
  });
}

chrome.storage.local.get("menuItems", (data) => {
  const items = data.menuItems || [];
  fetch("menu-data.json")
    .then((res) => res.json())
    .then((defaultItems) => {
      const merged = items.length ? items : defaultItems;
      renderMenu(merged);
    });
});