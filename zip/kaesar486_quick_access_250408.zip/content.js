(function main() {
  const expectedStreamerId = "39fa62e81c7d74d9d18610fa6e3d5bdb";
  if (!window.location.href.includes(expectedStreamerId)) {
    console.log("다른 방송이므로 content.js 실행 안 함");
    return;
  }

  const observer = new MutationObserver(function () {
    const target = document.querySelector(".live_chatting_input_donation__-Vqe\\+");
    if (!target) return;

    if (document.querySelector(".quick-menu-button")) {
      return;
    }

    const buttons = [
      {
        url: "https://www.youtube.com/channel/UCHNYENAm5cyDtQ7Km_Fh-YQ",
        img: "https://raw.githubusercontent.com/nrirn/NRirn_Public/main/images/youtube_kaesar486.png",
        alt: "유튜브",
        tooltip: "유튜브"
      },
      {
        url: "https://cafe.naver.com/kaesar486",
        img: "https://raw.githubusercontent.com/nrirn/NRirn_Public/main/images/cafe_kaesar486.png",
        alt: "팬카페",
        tooltip: "팬카페"
      }
    ];

    buttons.forEach((btn) => {
      const wrapper = document.createElement("div");
      wrapper.className = "quick-menu-button";
      wrapper.style.position = "relative";
      wrapper.style.display = "inline-block";
      wrapper.style.marginLeft = "10px";

      const link = document.createElement("a");
      link.href = btn.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";

      const icon = document.createElement("img");
      icon.src = btn.img;
      icon.alt = btn.alt;
      icon.style.height = "24px";
      icon.style.width = "24px";
      icon.style.borderRadius = "4px";
      icon.style.cursor = "pointer";

      const tooltip = document.createElement("div");
      tooltip.textContent = btn.tooltip;
      tooltip.style.visibility = "hidden";
      tooltip.style.position = "absolute";
      tooltip.style.bottom = "calc(100% + 8px)";
      tooltip.style.left = "50%";
      tooltip.style.transform = "translateX(-50%)";
      tooltip.style.background = "#2e3033";
      tooltip.style.color = "#dfe2ea";
      tooltip.style.padding = "5px 8px";
      tooltip.style.borderRadius = "6px";
      tooltip.style.whiteSpace = "nowrap";
      tooltip.style.fontSize = "12px";
      tooltip.style.zIndex = "9999";

      wrapper.addEventListener("mouseenter", () => {
        tooltip.style.visibility = "visible";
      });

      wrapper.addEventListener("mouseleave", () => {
        tooltip.style.visibility = "hidden";
      });

      link.appendChild(icon);
      wrapper.appendChild(link);
      wrapper.appendChild(tooltip);

      target.appendChild(wrapper);
    });

    console.log("[QuickMenu] 버튼 삽입 완료");
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
})();
